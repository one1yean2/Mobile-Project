class Country {
  final String? name;
  final String? capital;
  final String? flag;
  final int? population;

  Country({
    required this.name,
    required this.capital,
    required this.population,
    required this.flag,
  });

  factory Country.fromJson(Map<String, dynamic> json) {
    return Country(
      name: json['name'],
      capital: json['capital'],
      flag: json['flag'],
      population: json['population'],
    );
  }
}
