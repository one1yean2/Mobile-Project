import 'dart:convert';

import 'package:api_homework/country.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

class ApiPage extends StatefulWidget {
  const ApiPage({super.key});

  @override
  State<ApiPage> createState() => _ApiPageState();
}

class _ApiPageState extends State<ApiPage> {
// State variable
  List<Country>? _countries;

// เมธอดสำหรับโหลดข้อมูล
  // void _getCountries() async {
  //   var dio = Dio(BaseOptions(responseType: ResponseType.plain));
  //   var response = await dio.get('https://api.sampleapis.com/countries/countries');
  //   List list = jsonDecode(response.data);

  //   setState(() {
  //     _countries = list.map((country) => Country.fromJson(country)).toList();

  //     // เรียงลำดับตามชื่อจาก A ไป Z (กรณีต้องการเรียงลำดับ)
  //     // _countries!.sort((a, b) => a.name.compareTo(b.name));
  //   });
  // }

  // @override
  // void initState() {
  //   super.initState();
  //   // เรียกเมธอดสำหรับโหลดข้อมูลใน initState() ของคลาสที่ extends มาจาก State
  //   _getCountries();
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          ElevatedButton(
            onPressed: () async {
              var dio = Dio(BaseOptions(responseType: ResponseType.plain));
              var response = await dio.get('https://api.sampleapis.com/countries/countries');
              setState(() {
                List list = jsonDecode(response.data);

                _countries = list.map((country) => Country.fromJson(country)).toList();

                // _countries = list.map<Country>((country) {
                //   return Country(
                //     name: country['name'],
                //   );
                // }).toList();

                // เรียงลำดับตามชื่อจาก A ไป Z (กรณีต้องการเรียงลำดับ) ยังทำไม่ได้
                // _countries!.sort((a, b) => a.name.compareTo(b.name));
              });
            },
            child: Text('Get countries'),
          ),
          Expanded(
            child: _countries == null
                ? SizedBox.shrink()
                : ListView.builder(
                    itemCount: _countries!.length,
                    itemBuilder: (context, index) {
                      var country = _countries![index];

                      return ListTile(
                        title: Text(country.name ?? ''),
                        subtitle: Text(country.capital ?? ''),
                        leading: Text(country.flag ?? ''),
                        trailing: Text(country.population.toString()),
                        onTap: () {
                          print('you click ${country.name}');
                        },
                      );
                    },
                  ),
          )
        ],
      ),
    );
  }
}
